/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mymovie;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author admin
 */
public class admin2 extends javax.swing.JFrame {

    /**
     * Creates new form 
     */
    int num;
    ResultSet r;
    public admin2(int num,String name) {
        initComponents();
        setTitle("admin2");
        setSize(1920,1080);
        this.num= num;
        try
        {
            String q = "select date,time,screen,movie_name from theaters inner join screenid on theaters.th_number = screenid.th_number inner join showid on showid.screen_id= screenid.screen_id inner join movies on showid.movie_id = movies.movie_id where theaters.th_number = ?";
            java.sql.Connection con= DriverManager.getConnection("jdbc:mysql://127.0.0.01:3306/OMT", "root", ""); 
            PreparedStatement pstmt = con.prepareStatement(q);
            pstmt.setInt(1, num);
            r = pstmt.executeQuery();
            Font f = new Font("Tahoma", 1, 18);
            r.next();
            jPanel4.setPreferredSize(new Dimension(1150,500));
            jPanel4.setLayout(new FlowLayout(FlowLayout.CENTER));

            for(int i=0;i<4;i++)
            {  
                JPanel p =new JPanel(new FlowLayout(FlowLayout.CENTER));
                p.setSize(new Dimension(250,40));
                JLabel l1 = new JLabel();

                if(i==0)
                l1.setText("Date");
                if(i==1)
                l1.setText("Time");
                if(i==2)
                l1.setText("Screen No.");
                if(i==3)
                l1.setText("Movie Name");
                if(i==4)
                l1.setText("   ");

                l1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                l1.setFont(new java.awt.Font("Arial", 1, 24));
                l1.setPreferredSize(new Dimension(250,20));
                p.add(l1);
                jPanel4.add(p);
            }
            
            
            int temp;
      int x=0;
      while(r.next()){
          x++;
            for(int i=0;i<5;i++){  
            JPanel p1 =new JPanel(new FlowLayout(FlowLayout.CENTER));
            p1.setSize(new Dimension(250,25));
            JLabel l1 = new JLabel();

            if(i==0)
            {    
               q= r.getString("date");
               //System.out.println("th_name: "+q);
                p1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
               l1.setText(q);
            }
            if(i==1)
            {    
               q= r.getString("time");
               System.out.println("Time: "+q);
                p1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
               l1.setText(q);
            }
            if(i==2)
            {    
               temp= r.getInt("screen");
               System.out.println("Screen: "+temp);
                p1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
               l1.setText(temp+"");
            }
             if(i==3)
            {    
               q= r.getString("movie_name");
               System.out.println("tickets: "+q);
                p1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
               l1.setText(q+"");
            }
            /*if(i==4)
            {    
              
               JButton b = new JButton("Book Tickets");
               b.setSize(new Dimension(319,10));
               b.setFont(new java.awt.Font("Arial", 1, 12));
               b.setActionCommand(x+"");
               b.addActionListener(new ActionListener() {
                   
               public void actionPerformed(ActionEvent evt) {
               bActionPerformed(evt,r);}
               });
               
               p1.add(b);
              
            }   
*/
            if(i!=4){
            l1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            l1.setFont(new java.awt.Font("Arial", 1, 18));
            l1.setPreferredSize(new Dimension(250,25));
            if(i%2==0)
                l1.setForeground(new java.awt.Color(0, 153, 153));
            else
                 l1.setForeground(new java.awt.Color(0, 102, 102));
            System.out.println("Adding Label when i="+i);
            p1.add(l1);
            }
            jPanel4.add(p1);
      }
      }
            
            
            
            /*JPanel p1 = new JPanel();
            p1.setBackground(Color.magenta);
            p1.setLayout(new FlowLayout());
            while(r.next())
            {
                System.out.println(r.getString("date")+"    "+r.getString("time")+"     "+r.getInt("screen")+"      "+r.getString("movie_name"));
                JLabel l1 = new JLabel(r.getString("date"));
                l1.setFont(f);
                JLabel l2 = new JLabel(r.getString("time"));
                l2.setFont(f);
                JLabel l3 = new JLabel(r.getString("screen"));
                l3.setFont(f);
                JLabel l4 = new JLabel(r.getString("movie_name"));
                l4.setFont(f);
                jPanel4.add(l1);
                jPanel4.add(l2);
                jPanel4.add(l3);
                jPanel4.add(l4);
            }*/
            
        }
        catch(SQLException e){System.out.println(e);}
        }
 

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 102, 102));

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mymovie/images/667356-256.png"))); // NOI18N

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mymovie/images/667356-256-ConvertImage.png"))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("MOVIES MAGIC");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 479, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 461, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(468, 468, 468)
                .addComponent(jLabel4))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel16)
                    .addComponent(jLabel4))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(153, 255, 204));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1264, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 629, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(316, 316, 316))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(admin2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(admin2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(admin2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(admin2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                //new admin2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    // End of variables declaration//GEN-END:variables
}
