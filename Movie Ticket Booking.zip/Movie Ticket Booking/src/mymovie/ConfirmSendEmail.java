package mymovie;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


public class ConfirmSendEmail extends javax.swing.JFrame {
    static String email;
    static String movie; static String theater; static int screen; static String date; static String time; static String seats;
    public ConfirmSendEmail(String movie, String theater, int screen, String date,String time, String seats) {
        this.movie=movie;
        this.theater= theater;
        this.screen= screen;
        this.time= time;
        this.date= date;
        this.seats=seats;
        email= login.s1;
        mainmethod();
    }

public static void mainmethod() {

		final String username = "moviesmagic.kit@gmail.com";
		final String password = "javaproject";
                System.out.println("email id is: "+email);
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");

		Session session = Session.getInstance(props,
		  new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		  });

		try {

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("moviesmagic.kit@gmail.com"));
			message.setRecipients(Message.RecipientType.TO,
                        InternetAddress.parse(email));
			message.setSubject("Booking Confirmed");
			message.setText("Thank you for booking tickets on MoviesMagic. Ticket details are as follows:\n\nMovie:\t"+movie+"\nTheater:\t"+theater+"\nScreen:\t"+screen+"\nDate:\t"+date+"\nTime:\t"+time+"\nSeats:\t"+seats);
                        System.out.println("here1");
			Transport.send(message);
                        System.out.println("here2");
			System.out.println("Done");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}
}
