/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mymovie;

/**
 *
 * @author admin
 */
public class MovieTicketAjinkya {
    
    public static void main(String args[])
    {
        //new CityDate().setVisible(true);
        //new ShowAll2().setVisible(true);
        //new CityDate().setVisible(true);
        //new Payment().setVisible(true);
        //new signup().setVisible(true);
        //new SetMaps().setVisible(true);
        new NewJFrame().setVisible(true);
        //new MovieDetails().setVisible(true);
    }
    
}
