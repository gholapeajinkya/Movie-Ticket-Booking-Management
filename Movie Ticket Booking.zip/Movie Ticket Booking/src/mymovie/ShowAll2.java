package mymovie;


import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.ScrollPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;


public class ShowAll2 extends javax.swing.JFrame implements ActionListener{

    
    java.sql.Connection con;
    PreparedStatement pstmt;
    ResultSet rs,rs1,rs2;
    JPanel p2,p3,p4;
    JScrollPane sp;
    JButton b1,b2,b3,back;
    JLabel l1,l2,l3,l4;
    String typ,rate,mnb,lan,path;
    JComboBox cb;
    Font f1;
    String ch1,ch2;
    static String aj="Sort By Movie Name";
    
    @SuppressWarnings("empty-statement")
    public ShowAll2() {
        initComponents();
        //setLayout(null);
        setSize(1920,1080);
        setTitle("ShowAll");
        makeMainWindow();
        //
        try {
                back = new JButton("Back");
                back.setBounds(0, 1050, 30, 20);
                add(back);
                p2 = new JPanel();
                p2.setLayout(new GridLayout(6, 10 , 80 , 80));
                int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS;
                int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER;
                sp = new JScrollPane(p2,v,h);
                //for(int i=0;i<c;i++)
                b3 = new JButton("OK");
                String sortby[] ={"Sort By Movie Name","Sort By Ratings","Sort By Language"};
                cb =new JComboBox(sortby);
                f1 = new Font("Tahoma",1,18);
                cb.setFont(f1);
                cb.setBounds(1500,288,300,40);
                b3.setBounds(1580, 350, 100, 50);
                add(cb);
                add(b3);
                con = (java.sql.Connection) java.sql.DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/omt","root","");
                pstmt = con.prepareStatement("select * from movies");
                rs = pstmt.executeQuery();
                while(rs.next())
                {
                    path = rs.getString("image_path");
                    b1 = new JButton(new ImageIcon(path));
                    System.out.println("ajinkya   "+path);
                    p4 = new JPanel();
                    p4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
                    p4.setLayout(null);
                    l2 = new JLabel("rate");
                    l3 = new JLabel(new ImageIcon("D:\\study\\MovieTicket\\mymovie\\src\\mymovie\\images\\211673-32.png"));
                    l1 = new JLabel("type");
                    b2 = new JButton("Movie Name");
                    b2.setBackground(new Color(255,102,102));
                    b2.setForeground(Color.WHITE);
                    b1.setBounds(0,0,250,370);
                    b2.setBounds(25,373,200,40);
                    final String name= rs.getString("movie_name");
                    (b1).addActionListener(new java.awt.event.ActionListener() 
                    {
                        public void actionPerformed(java.awt.event.ActionEvent evt) 
                        {
                            b1ActionPerformed(evt,name);
                        }
                    });
                    
                    l1.setBounds(2, 420, 70, 20);
                    l2.setBounds(225,420,40,32);
                    l3.setBounds(195,420,32,32);
                    lan = rs.getString("language");
                    typ = rs.getString("type");
                    rate = rs.getString("ratings");
                    mnb = rs.getString("movie_name");
                    
                    b2.setText(mnb);
                    l1.setText(typ);
                    l2.setText(rate+"%");
                    //
                    p4.add(b1);
                    p4.add(b2);
                    p4.add(l1);
                    p4.add(l3);
                    p4.add(l2);
                    p4.setPreferredSize(new Dimension(250, 450));
                    p2.add(p4);
                    
                    b1.addActionListener((ActionListener) this);
                    b2.addActionListener((ActionListener) this);
                }
                //tanmay(rs);
                b3.addActionListener((new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) 
                    {
                        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                            if(e.getSource()==b3)
                            {
                                aj = (String) cb.getItemAt(cb.getSelectedIndex());
                                System.out.println(aj);
                                switch(aj)
                                {
                                    case "Sort By Movie Name":
                                    {
                                        try {
                                            System.out.println("I am in case Sort By Movie name");
                                            pstmt = con.prepareStatement("select * from movies order by movie_name");
                                            rs1 = pstmt.executeQuery();
                                            tanmay(rs1);
                                        } catch (SQLException ex) {
                                            Logger.getLogger(ShowAll2.class.getName()).log(Level.SEVERE, null, ex);
                                        }
                                    }
                                    break;
                                    case "Sort By Ratings":
                                    {
                                        try 
                                        {
                                            System.out.println("I am in case Sort By Ratings");
                                            pstmt = con.prepareStatement("select * from movies order by ratings DESC");
                                            rs2 = pstmt.executeQuery();
                                            tanmay(rs2);
                                        } catch (SQLException ex) {
                                            Logger.getLogger(ShowAll2.class.getName()).log(Level.SEVERE, null, ex);
                                        }
                                    }
                                    break;
                                    case "Sort By Language":
                                    {
                                    try {
                                        pstmt = con.prepareStatement("select * from movies order by language DESC");
                                        rs = pstmt.executeQuery();
                                        tanmay(rs);
                                    } catch (SQLException ex) {
                                        Logger.getLogger(ShowAll2.class.getName()).log(Level.SEVERE, null, ex);
                                    }
                                    }
                                    break;
                                    case "Sort By Year":
                                    {
                                    try {
                                        pstmt = con.prepareStatement("select * from movies");
                                        rs = pstmt.executeQuery();
                                        tanmay(rs);
                                    } catch (SQLException ex) {
                                        Logger.getLogger(ShowAll2.class.getName()).log(Level.SEVERE, null, ex);
                                    }
                                    }

                                }
                            }
                    }
                }));
                
            }
            catch (SQLException ex) {
            Logger.getLogger(MovieList.class.getName()).log(Level.SEVERE, null, ex);
            }
        
            sp.setBounds(430,288,929,800);
            this.add(sp);
        //

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    private void b1ActionPerformed(java.awt.event.ActionEvent evt, String a) {                                         
        // TODO add your handling code here:
        try{
        java.sql.Connection con= DriverManager.getConnection("jdbc:mysql://127.0.0.01:3306/OMT", "root", ""); 
        String q= "select * from movies where movie_name=(?)";
        PreparedStatement pstmt = con.prepareStatement(q);
        pstmt.setString(1, a);
        ResultSet r= pstmt.executeQuery();
        r.next();
        String path = r.getString("image_path"); 
        
       System.out.println("Selected Movie Name: "+a);
       //Frame3 f3 =new Frame3(r.getInt("movie_id"),a);
       MovieDetails md = new MovieDetails(r.getInt("movie_id"),a,path);
       md.setVisible(true);
        }
        catch(SQLException e){System.out.println(e);}
        
    } 
    public void actionPerformed(ActionEvent e)
    {
        
        /*if(e.getSource()==b3)
        {
            ch2 = (String) cb.getItemAt(cb.getSelectedIndex());
            System.out.println(ch2);
            b3.setText(ch2);
        }*/
    }  
    public void tanmay(ResultSet rs) throws SQLException
    {
        p2.removeAll();
	while(rs.next())
        {
            
            try {
                path = rs.getString("image_path");
                System.out.println(path);
                b1 = new JButton(new ImageIcon(path));
                p4 = new JPanel();
                p4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
                p4.setLayout(null);
                l2 = new JLabel("rate");
                l3 = new JLabel(new ImageIcon("D:\\study\\MovieTicket\\mymovie\\src\\mymovie\\images\\211673-32.png"));
                l1 = new JLabel("type");
                b2 = new JButton("Movie Name");
                b2.setBackground(new Color(255,102,102));
                b2.setForeground(Color.WHITE);
                b1.setBounds(0,0,250,370);
                b2.setBounds(25,373,200,40);
                l1.setBounds(2, 420, 70, 20);
                l2.setBounds(225,420,40,32);
                l3.setBounds(195,420,32,32);
                lan = rs.getString("language");
                typ = rs.getString("type");
                rate = rs.getString("ratings");
                mnb = rs.getString("movie_name");
                
                b2.setText(mnb);
                l1.setText(typ);
                l2.setText(rate+"%");
                //
                p4.add(b1);
                p4.add(b2);
                p4.add(l1);
                p4.add(l3);
                p4.add(l2);
                p4.setPreferredSize(new Dimension(250, 450));
                p2.add(p4);
                
                b1.addActionListener((ActionListener) this);
                b2.addActionListener((ActionListener) this);
            } catch (SQLException ex) {
                Logger.getLogger(ShowAll2.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }   
    public void makeMainWindow()
    {
        JPanel p1;
        JLabel l1,l2,l3;
        p1 = new JPanel();
        p1.setLayout(null);
        p1.setBackground(new Color(255,102,102));
       // p1.setPreferredSize(new Dimension(1920,262));
        l1 = new JLabel(new ImageIcon("D:\\study\\MovieTicketAjinkya\\src\\mymovie\\images667356-256.png"));
        l2 = new JLabel("Movies Magic");
        l2.setFont(new Font("Tahoma",Font.BOLD,48));
        l2.setForeground(Color.white);
        l3 = new JLabel(new ImageIcon("D:\\study\\MovieTicketAjinkya\\src\\mymovie\\images\\667356-256-ConvertImage.png"));
        p1.setBounds(0, 0, 1920, 262);
        l1.setBounds(0, 0, 256, 256);
        l2.setBounds(800, 100, 400, 65);
        l3.setBounds(1645, 0, 256, 256);
        p1.add(l1);
        p1.add(l2);
        p1.add(l3);
        add(p1);
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ShowAll2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ShowAll2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ShowAll2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ShowAll2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ShowAll2().setVisible(true);
            }
        });
    }

    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
//UPDATE movies SET image_path='D:\study\MovieTicket\mymovie\src\mymovie\images\jub harry met sajal.jpg' where movie_name='';
//INSERT INTO movies VALUES('Sui Dhaaga','28/9/2018',65,'Comedy','Hindi','D:\\study\\MovieTicket\\mymovie\\src\\mymovie\\images\\sui dhaaga.jpg')